SkyloraDonate 3.0.0 resource pack for Minecraft Java 1.21.4.
Private-use glyphs: U+E200..U+E205.
The pack extends minecraft:default so normal text remains available.

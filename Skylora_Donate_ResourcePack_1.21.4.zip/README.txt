SKYLORA DONATE RESOURCE PACK
Minecraft Java 1.21.4
Resource pack format: 46

The pack provides six custom donate badges as private-use Unicode glyphs.

DRAGON  = 
TITAN   = 
PHOENIX = 
PREMIUM = 
VIP     = 
HERO    = 

Font ID:
  skylora:badges
  minecraft:skylora

Example MiniMessage:
  <font:skylora:badges>\uE000</font>

Or use the literal glyph from above:
  <font:skylora:badges></font>

Important:
This is the visual resource pack only. A plugin/TAB/chat system still has to output the custom glyph.

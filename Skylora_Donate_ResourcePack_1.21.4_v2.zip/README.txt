Skylora Donate Resource Pack v2
Minecraft Java 1.21.4

Custom glyphs: dragon, titan, phoenix, premium, vip, hero.
The glyphs are icon-only so the plugin can change the donation text/prefix without changing the icon.
